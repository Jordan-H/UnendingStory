A Pen created at CodePen.io. You can find this one at http://codepen.io/markmurray/pen/JugrG.

 10 different share button styles with social icons to be stolen or used for inspiration!